# 万历十四年·朱笔未落 — UI Kit v1（黑金档案馆）

本包提供：UI图标/按钮/框体/纹理（PNG，透明或可平铺），用于网页剧本杀/VN式对话界面。

## 目录
- icons/png_128/  128x128 透明图标（适合直接用或缩放）
- icons/png_256/  256x256 透明图标（高清源）
- buttons/        按钮底图（600x160）+ 行动条签条（900x120）
- frames/dialogue/ 三种底部对话框皮肤（1920x420）：阅示/过堂/入档
- frames/panels/  通用面板/弹层框体
- textures/seamless_2048/  2048x2048 可平铺纹理
- theme/theme.json 配色令牌与约束说明
- manifests/ui_manifest_additions.json  可直接合并到 assets/manifest.json 的条目列表

## 命名规则
- ICON_*  图标
- BTN_*   按钮底图（含 normal/hover/pressed/disabled）
- FRAME_* 框体/面板
- TEX_*   纹理（可平铺）

## 使用建议（符合Bible）
- COLD_BASE 做全局底，PAPER_INFO 做文本承载纸面。
- GOLD_ORDER 只做边界/铭牌/编号槽，不铺满。
- RED_DECISION 只用于裁断/风险/入档节点（例如：确认归档、风险角标、封条开缝）。

